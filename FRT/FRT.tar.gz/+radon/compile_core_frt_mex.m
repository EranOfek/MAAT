setenv MAT /home/eran/matlab/fun/guy/
str = ['mex CXXFLAGS="$CXXFLAGS -O4 -std=c++11" ' getenv('MAT') '/+radon/coreFRT.cpp -outdir ' getenv('MAT') '/+radon'];

eval(str);